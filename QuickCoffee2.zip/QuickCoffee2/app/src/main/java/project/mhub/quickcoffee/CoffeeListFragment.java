package project.mhub.quickcoffee;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.Arrays;

/**
 * Created by USER on 10/22/2016.
 */
public class CoffeeListFragment extends Fragment {
    private Coffee[] mCoffees;

    public interface OnCoffeeItemSelected {
        void onListCoffeeSelected(int index);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        OnCoffeeItemSelected listener = (OnCoffeeItemSelected) getActivity();
        View view = inflater.inflate(R.layout.fragment_coffee_list, container, false);

        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);

        Parcelable[] parcelables = getArguments().getParcelableArray(MainActivity.COFFEE_ARRAY);
        mCoffees = Arrays.copyOf(parcelables, parcelables.length, Coffee[].class);

        CoffeeListAdapter adapter = new CoffeeListAdapter(mCoffees, listener);

        recyclerView.setAdapter(adapter);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

//        recyclerView.setHasFixedSize(true);

        return view;
    }

}
