package project.mhub.quickcoffee;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by USER on 10/22/2016.
 */
public class Coffee implements Parcelable{
    private String mName;
    private String mDescription;
    private String mPrice;
    private int mPreviewImage;
    private int mFeaturedImage;

    public Coffee(String name, String description, String price, int previewImage, int featuredImage) {
        mName = name;
        mDescription = description;
        mPrice = price;
        mPreviewImage = previewImage;
        mFeaturedImage = featuredImage;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getDescription() {
        return mDescription;
    }

    public void setDescription(String description) {
        mDescription = description;
    }

    public String getPrice() {
        return mPrice;
    }

    public void setPrice(String price) {
        mPrice = price;
    }

    public int getPreviewImage() {
        return mPreviewImage;
    }

    public void setPreviewImage(int previewImage) {
        mPreviewImage = previewImage;
    }

    public int getFeaturedImage() {
        return mFeaturedImage;
    }

    public void setFeaturedImage(int featuredImage) {
        mFeaturedImage = featuredImage;
    }

    public static final Creator<Coffee> CREATOR = new Creator<Coffee>() {
        @Override
        public Coffee createFromParcel(Parcel in) {

            return new Coffee(in);
        }

        @Override
        public Coffee[] newArray(int size) {
            return new Coffee[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mName);
        dest.writeString(mDescription);
        dest.writeString(mPrice);
        dest.writeInt(mPreviewImage);
        dest.writeInt(mFeaturedImage);
    }

    private Coffee(Parcel in) {
        mName = in.readString();
        mDescription = in.readString();
        mPrice = in.readString();
        mPreviewImage = in.readInt();
        mFeaturedImage = in.readInt();
    }
}
