package project.mhub.quickcoffee;

import android.support.v4.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity implements CoffeeListFragment.OnCoffeeItemSelected {
    public static final String LIST_FRAGMENT = "list_fragment";
    public static final String DETAILED_FRAGMENT = "detailed_fragment";
    public static final String SELECTION_INDEX = "selection_index";
    public static final String COFFEE_ARRAY = "coffee_array";

    private Coffee[] mCoffees;
    private Bundle coffeeBundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        populateCoffee();
        CoffeeListFragment savedFragment = (CoffeeListFragment) getSupportFragmentManager().findFragmentByTag(LIST_FRAGMENT);
        coffeeBundle = new Bundle();
        coffeeBundle.putParcelableArray(COFFEE_ARRAY, mCoffees);

        if (savedFragment == null) {
            CoffeeListFragment coffeeListFragment = new CoffeeListFragment();
            coffeeListFragment.setArguments(coffeeBundle);
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.add(R.id.listContainer, coffeeListFragment, LIST_FRAGMENT);

            fragmentTransaction.commit();
        }

    }



//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.menu_main, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
//    }

    @Override
    public void onListCoffeeSelected(int index) {
        Bundle indexBundle = new Bundle();
        indexBundle.putInt(SELECTION_INDEX, index);
        coffeeBundle.putAll(indexBundle);

        CoffeeDetailedFragment savedFragment = (CoffeeDetailedFragment) getSupportFragmentManager().findFragmentByTag(DETAILED_FRAGMENT);

        if (savedFragment == null) {
            CoffeeDetailedFragment coffeeDetailedFragment = new CoffeeDetailedFragment();
            coffeeDetailedFragment.setArguments(coffeeBundle);
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.listContainer, coffeeDetailedFragment, DETAILED_FRAGMENT);

            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();
        }

    }


    public Coffee[] populateCoffee() {
        mCoffees = new Coffee[7];

        // Populated Dummy Content
        mCoffees[0] = new Coffee("Latte", getString(R.string.latte_desc), "$1.99", R.drawable.latte_preview, R.drawable.latte);
        mCoffees[1] = new Coffee("Black Coffee", getString(R.string.coffee_black), "$1.99", R.drawable.coffee_black_preview, R.drawable.coffee_black);
        mCoffees[2] = new Coffee("Decaffeinated Coffee", getString(R.string.coffee_decaf), "$0.99", R.drawable.coffee_decaf_preview, R.drawable.coffee_decaf);
        mCoffees[3] = new Coffee("Coffee and Cream", getString(R.string.coffee_cream), "$1.49", R.drawable.coffee_cream_preview, R.drawable.coffee_cream);
        mCoffees[4] = new Coffee("Cappuccino", "Coffee milk is a drink made by mixing coffee syrup and milk together in a manner similar to chocolate milk. It is the official state drink of Rhode Island in the United States of America.", "$2.00", R.drawable.cappuccino_preview, R.drawable.cappuccino);
        mCoffees[5] = new Coffee("Coffee and Milk", "Coffee preparation is the process of turning coffee beans into a beverage. While the particular ... The whole coffee beans are ground, also known as milling, to facilitate the brewing process. The fineness of the grind strongly affects brewing.", "$1.20", R.drawable.coffee_milk_preview, R.drawable.coffee_milk);
        mCoffees[6] = new Coffee("Crushed Coffee", getString(R.string.coffee_black), "$1.99", R.drawable.coffee_crushed_preview, R.drawable.coffee_crushed);

        return mCoffees;
    }

}
