package project.mhub.quickcoffee;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by USER on 10/22/2016.
 */
public class CoffeeListAdapter extends RecyclerView.Adapter <CoffeeListAdapter.CoffeeListViewHolder> {
    private Coffee[] mCoffees;
    private final CoffeeListFragment.OnCoffeeItemSelected mListener;

    public CoffeeListAdapter(Coffee[] coffees, CoffeeListFragment.OnCoffeeItemSelected listener) {
        mCoffees = coffees;
        mListener = listener;
    }

    @Override
    public CoffeeListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.coffee_list_item, parent, false);
        return new CoffeeListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CoffeeListViewHolder holder, int position) {
        holder.bindView(position);
    }

    @Override
    public int getItemCount() {
        return mCoffees.length;
    }

    public class CoffeeListViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private ImageView mPreviewImage;
        private TextView mCoffeeName;
        private TextView mCoffeePrice;
        private int mCurrentIndex;

        public CoffeeListViewHolder(View itemView) {
            super(itemView);

            mPreviewImage = (ImageView) itemView.findViewById(R.id.itemImage);
            mCoffeeName = (TextView) itemView.findViewById(R.id.itemName);
            mCoffeePrice = (TextView) itemView.findViewById(R.id.itemPrice);

            itemView.setOnClickListener(this);
        }

        public void bindView(int position) {
            mPreviewImage.setImageResource(mCoffees[position].getPreviewImage());
            mCoffeeName.setText(mCoffees[position].getName());
            mCoffeePrice.setText(mCoffees[position].getPrice());
            mCurrentIndex = position;
        }

        @Override
        public void onClick(View v) {
            mListener.onListCoffeeSelected(mCurrentIndex);
        }
    }
}
