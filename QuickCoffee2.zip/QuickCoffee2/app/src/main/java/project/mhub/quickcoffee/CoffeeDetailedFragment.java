package project.mhub.quickcoffee;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Arrays;

/**
 * Created by USER on 10/22/2016.
 */
public class CoffeeDetailedFragment extends Fragment {

    private TextView mCoffeeNameLabel;
    private TextView mCoffeePriceLabel;
    private TextView mCoffeeDescription;
    private ImageView mFeaturedImage;
    private Coffee[] mCoffees;
    private int mIndex;

    // Ecocash specific payment details
    // The variables currently contains dummy data
    private static final String ECOCASH_CODE = "*151*";
    private static final String BILLERCODE = "";
    private static final String MERCHANT = "";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_coffee_detailed, container, false);

        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + ECOCASH_CODE + BILLERCODE +"#"));
                startActivity(intent);
            }
        });

        Parcelable[] parcelables = getArguments().getParcelableArray(MainActivity.COFFEE_ARRAY);
        mCoffees = Arrays.copyOf(parcelables, parcelables.length, Coffee[].class);
        mIndex = getArguments().getInt(MainActivity.SELECTION_INDEX);

        //mIndex = savedInstanceState.getInt(MainActivity.SELECTION_INDEX);


        mCoffeeNameLabel = (TextView) view.findViewById(R.id.coffeeNameLabel);
        mCoffeePriceLabel = (TextView) view.findViewById(R.id.coffeePriceLabel);
        mCoffeeDescription = (TextView) view.findViewById(R.id.coffeeDescription);
        mFeaturedImage = (ImageView) view.findViewById(R.id.featuredImage);

        // Setting the Values Displayed
        mCoffeeNameLabel.setText(mCoffees[mIndex].getName());
        mCoffeePriceLabel.setText(mCoffees[mIndex].getPrice());
        mCoffeeDescription.setText(mCoffees[mIndex].getDescription());
        mFeaturedImage.setImageResource(mCoffees[mIndex].getFeaturedImage());

        return view;
    }
}
