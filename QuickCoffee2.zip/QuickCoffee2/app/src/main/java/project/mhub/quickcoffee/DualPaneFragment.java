package project.mhub.quickcoffee;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.Arrays;

/**
 * Created by USER on 10/24/2016.
 */
public class DualPaneFragment  extends Fragment {

    private static final String MENU_FRAGMENT = "menu_fragment";
    private Coffee[] mCoffees;
    private int mIndex;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dualpane, container, false);

        Parcelable[] parcelables = getArguments().getParcelableArray(MainActivity.COFFEE_ARRAY);
        mCoffees = Arrays.copyOf(parcelables, parcelables.length, Coffee[].class);
        mIndex = getArguments().getInt(MainActivity.SELECTION_INDEX);

        FragmentManager fragmentManager = getChildFragmentManager();
        CoffeeListFragment savedFragment = (CoffeeListFragment) fragmentManager.findFragmentByTag(MENU_FRAGMENT);

        if (savedFragment == null) {
            CoffeeListFragment coffeeListFragment = new CoffeeListFragment();

            // Setting up Bundles
            Bundle coffeeBundle = new Bundle();
            Bundle indexBundle = new Bundle();
            indexBundle.putInt(MainActivity.SELECTION_INDEX, mIndex);
            coffeeBundle.putParcelableArray(MainActivity.COFFEE_ARRAY, mCoffees);
            coffeeBundle.putAll(indexBundle);

            coffeeListFragment.setArguments(coffeeBundle);
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.add(R.id.leftPlaceholder, coffeeListFragment, MainActivity.LIST_FRAGMENT);

            fragmentTransaction.commit();
        }

        CoffeeDetailedFragment savedDetailedFragment = (CoffeeDetailedFragment) fragmentManager.findFragmentByTag(MENU_FRAGMENT);

        if (savedDetailedFragment == null) {
            CoffeeDetailedFragment coffeeDetailedFragment = new CoffeeDetailedFragment();

            // Setting up Bundles
            Bundle coffeeBundle = new Bundle();
            Bundle indexBundle = new Bundle();
            indexBundle.putInt(MainActivity.SELECTION_INDEX, mIndex);
            coffeeBundle.putParcelableArray(MainActivity.COFFEE_ARRAY, mCoffees);
            coffeeBundle.putAll(indexBundle);

            coffeeDetailedFragment.setArguments(coffeeBundle);
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.add(R.id.rightPlaceholder, coffeeDetailedFragment, MainActivity.DETAILED_FRAGMENT);

            fragmentTransaction.commit();
        }

        return view;
    }
}
